<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('details', function (Blueprint $table) {
            $table->id();
            $table->string('title')->required();
            $table->string('slug')->required();
            $table->string('address')->nullable();
            $table->string('phone')->nullable();
            $table->string('skype_id')->nullable();
            $table->string('teaching_experience')->nullable();
            $table->string('teaching_history')->nullable();
            $table->string('upload_resume')->nullable();
            $table->string('video_link')->nullable();
            $table->string('your_website')->nullable();
            $table->string('teacher_training_organization')->nullable();
            $table->string('profile_pic')->nullable();
            $table->longText('desc');
            $table->longText('short_desc');
            $table->string('featured_image');
            $table->string('featured_video');
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('details');
    }
};