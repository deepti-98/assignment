<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('title')->nullable();
            $table->string('slug')->nullable();
            $table->string('address')->nullable();
            $table->string('phone')->nullable();
            $table->string('skype_id')->nullable();
            $table->string('teaching_experience')->nullable();
            $table->string('teaching_history')->nullable();
            $table->string('upload_resume')->nullable();
            $table->string('video_link')->nullable();
            $table->string('your_website')->nullable();
            $table->string('teacher_training_organization')->nullable();
            $table->string('profile_pic')->nullable();
            $table->longText('desc')->nullable();
            $table->longText('short_desc')->nullable();
            $table->string('featured_image')->nullable();
            $table->string('featured_video')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            //
        });
    }
};