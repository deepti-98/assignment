<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Video;
use Illuminate\Auth\Access\Response;

class VideoPolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return $user->role_id == 1 || $user->status == 1;
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user){
        if($user->role_id == 1){
            return true;
        }else if($user->role_id == 0){
            if($user->status == 1){
                return true;
            }else{
                return false;
            }
        }
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        if($user->role_id == 1){
            return true;
        }else if($user->role_id == 0){
            if($user->status == 1){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

    /**
     * Determine whether the user can update the model.
     */
    // public function update(User $user, Video $video): bool
    // {
    //     //
    // }

    /**
     * Determine whether the user can delete the model.
     */
    // public function delete(User $user, Video $video): bool
    // {
    //     //
    // }

    /**
     * Determine whether the user can restore the model.
     */
    // public function restore(User $user, Video $video): bool
    // {
    //     //
    // }

    // /**
    //  * Determine whether the user can permanently delete the model.
    //  */
    // public function forceDelete(User $user, Video $video): bool
    // {
    //     //
    // }
}