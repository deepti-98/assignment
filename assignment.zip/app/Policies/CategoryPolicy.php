<?php

namespace App\Policies;

use App\Models\User;

class CategoryPolicy
{
    /**
     * Create a new policy instance.
     */
    public function __construct()
    {
        //
    }

    public function create(User $user)
    {
        return $user->role_id == 1;
    }

     public function viewAny(User $user): bool
    {
        return $user->role_id == 1 || $user->status == 1;
    }

    public function view(User $user)
    {
        return $user->role_id == 1;
    }

    // public function update(User $user)
    // {
    //     return $user->role_id === 1;
    // }

    public function delete(User $user)
    {
        return $user->role_id == 1;
    }
}