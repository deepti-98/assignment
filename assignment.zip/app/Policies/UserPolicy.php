<?php

namespace App\Policies;

use App\Models\User;

class UserPolicy
{
    /**
     * Create a new policy instance.
     */
    public function __construct()
    {
        //
    }

    public function create(User $user){
        return $user->role_id == 1;
    }

    public function view(User $user){
        if($user->role_id == 1){
            return true;
        }else if($user->role_id == 0){
            if($user->status == 1){
                return true;
            }
        }
    }

    public function delete(User $user){
        return $user->role_id == 1;
    }
}