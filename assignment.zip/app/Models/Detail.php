<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Detail extends Model
{
    use HasFactory;

    protected $fillable = ['title','slug','address', 'phone','skype_id','teaching_experience','teaching_history','teaching_history','upload_resume','video_link','your_website','teacher_training_organization','profile_pic','desc','short_desc','featured_image','featured_video','user_id'];

    public function user(){
        return $this->belongsTo(User::class);
    }
}