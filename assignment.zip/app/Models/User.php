<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Filament\Models\Contracts\FilamentUser;
use Spatie\Tags\HasTags;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, HasFactory, Notifiable, HasTags;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */

    protected $fillable = [
'name',
'email',
'password',
'role',
'teacher_id',
'role_id',
'title',
'slug'	,
'address',
'phone'	,
'skype_id',
'teaching_experience',
'teaching_history',
'upload_resume',
'video_link',
'your_website',
'teacher_training_organization'	,
'profile_pic',
'desc'	,
'short_desc',
'featured_image',
'featured_video',
'status'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    public function details(){
        return $this->hasOne(Detail::class);
    }

    // protected static function boot(){
    //     parent::boot();
    //     static::saving(function ($model) {
    //         $model->detail()->user_id = $model->id;
    //     });
    // }


    //  public function canAccessPanel(Panel $panel): bool
    // {
    //     return str_ends_with($this->email, '@monicatranter.com') && $this->hasVerifiedEmail();
    // }
}