<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Tags\HasTags;
class Video extends Model
{
    use HasFactory, SoftDeletes, HasTags;

    protected $fillable = ['title','description','short_desc','video_url', 'thumbnail', 'access','status', 'category_id'];


    public function category() : BelongsToMany
    {
        return $this->belongsToMany(Category::class);
    }

    public function teacher() : HasMany
    {
        return $this->hasMany(Teacher::class);
    }

    protected static function boot()
    {
        parent::boot();
        static::saving(function ($model) {
            $model->user_id = auth()->user()->id;
        });
    }

}