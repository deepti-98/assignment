<?php
namespace App\Subscriptions\PayPalSubscriptions;

use App\Subscriptions\Subscriptions;
use Exception;
use Illuminate\Support\Facades\Log;
use Srmklive\PayPal\Services\PayPal as PayPalClient;

class PayPalSubscriptions implements Subscriptions
{
    protected $provider;

    public function __construct(){
        $this->provider = new PayPalClient;

        $this->provider->setApiCredentials(config('paypal'));
    }

    public function create(int $plan_id, int $coupon_user_id, string $method, float $amount = 0){

        $response = $this->provider->addProduct('Demo Product', 'Demo Product', 'SERVICE', 'SOFTWARE')
                    ->addPlanTrialPricing('DAY', 7)
                    ->addDailyPlan('Demo Plan', 'Demo Plan', 1.50)
                    ->setReturnAndCancelUrl('https://example.com/paypal-success', 'https://example.com/paypal-cancel')
                    ->setupSubscription('John Doe', 'john@example.com', '2021-12-10');
    }
    public function cancel(string $subscription_id=null){
           $response = $this->provider->cancelSubscription($subscription_id, "reason");
    }
    public function pause(){


    }

    public function resume(){

    }
}