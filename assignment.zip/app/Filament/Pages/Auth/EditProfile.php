<?php

namespace App\Filament\Pages\Auth;

use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Pages\Auth\EditProfile as BaseEditProfile;
use Filament\Forms\Components\Card;
class EditProfile extends BaseEditProfile
{
    public function form(Form $form): Form
    {
        //$data = auth()->user();
        return $form
            ->schema([
                $this->getNameFormComponent(),
                TextInput::make('title')
                    ->required()
                    ->maxLength(255)
                    ->default('hello'),
                // $this->getPasswordFormComponent(),
                $this->getPasswordConfirmationFormComponent(),
            ]);
    }
}