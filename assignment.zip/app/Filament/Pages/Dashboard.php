<?php
namespace App\Filament\Pages;

use App\Filament\Resources\CustomerResource\Widgets\UserOverview;
use App\Filament\Resources\DashboardResource\Widgets\DashboardChart;
use App\Filament\Resources\DashboardResource\Widgets\UserChart;
use App\Filament\Resources\TeacherResource\Widgets\TeacherOverview;
use Filament\Pages\Dashboard as BasePage;

class Dashboard extends BasePage
{
    // protected static string $view = 'filament.resources.financial-resource.pages.content';
     protected $listeners = ['setStatusFilter' => 'updateTableFilters', 'setStatusFilter1' => 'updateTableFilters1','setStatusFilterTwo' => 'updateTableFiltersTwo', 'setStatusFilterCustomer' => 'updateTableFilterss', 'setStatusFilterCustomerNone' => 'updateTableFiltersNone'];
     public function getHeaderWidgets(): array
     {
        return [ TeacherOverview::class,
                  UserOverview::class,
                  DashboardChart::class,
                  UserChart::class
               ];
     }

     public function updateTableFilters(string $filter) {
         //$this->tableFilters['status']['value'] = $filter;
         return redirect()->to('admin/teacher?tableFilters[status][value]=');
    }
     public function updateTableFilters1(string $filter) {
         //$this->tableFilters['status']['value'] = $filter;
         return redirect()->to('admin/teacher?tableFilters[status][value]=1');
    }
     public function updateTableFiltersTwo(string $filter) {
         //$this->tableFilters['status']['value'] = $filter;
         return redirect()->to('admin/teacher?tableFilters[status][value]=0');
    }

     public function updateTableFilterss(string $filter) {
         return redirect()->to('admin/customers?tableFilters[status][value]=');
    }

    public function updateTableFiltersNone(string $filter) {
         return redirect()->to('admin/customers?tableFilters[status][value]=10');
    }
}