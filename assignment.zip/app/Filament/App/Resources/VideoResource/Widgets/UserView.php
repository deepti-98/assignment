<?php

namespace App\Filament\App\Resources\VideoResource\Widgets;

use Filament\Widgets\ChartWidget;

class UserView extends ChartWidget
{
    protected static ?string $heading = 'Video View Chart';
    protected int | string | array $columnSpan = 12;
    protected static ?string $maxHeight = '300px';

    protected function getData(): array
    {
        return [
            'datasets' => [
                [
                    'label' => 'Total',
                    'data' => [0, 30, 60, 2, 21, 11, 45, 74, 40, 45, 77, 20],
                ],
            ],
            'labels' => ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        ];
    }

    protected function getType(): string
    {
        return 'line';
    }

    public static function canView(): bool
    {
        if (auth()->user()->status == 1) {
            return true;
        } else {
            return false;
        }
    }
}