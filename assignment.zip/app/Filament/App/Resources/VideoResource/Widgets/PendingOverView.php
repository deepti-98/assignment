<?php

namespace App\Filament\App\Resources\VideoResource\Widgets;

use Filament\Widgets\Widget;

class PendingOverView extends Widget
{
    protected int | string | array $columnSpan = 12;
    protected static ?string $maxHeight = '300px';
    protected static string $view = 'filament.app.resources.video-resource.widgets.pending-over-view';

    public static function canView(): bool
    {
        if (auth()->user()->status == 0) {
            return true;
        } else {
            return false;
        }
    }
}