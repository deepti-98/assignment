<?php

namespace App\Filament\App\Resources;

use App\Filament\App\Resources\VideoResource\Pages;
use App\Filament\App\Resources\VideoResource\RelationManagers;
use App\Models\Video;
use App\Models\Category;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\Section;

class VideoResource extends Resource
{
    protected static ?string $model = Video::class;

    protected static ?string $navigationIcon = 'heroicon-o-video-camera';



    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Video Details')
                ->schema([
                   Forms\Components\TextInput::make('title')
                    ->required()
                    ->maxLength(255),
                   Forms\Components\Textarea::make('description')
                    ->columnSpanFull(),
                   Forms\Components\Textarea::make('short_desc')
                    ->columnSpanFull(),
                ])->columnSpan(2),

                Section::make('Video/Image')->schema([
                  Forms\Components\FileUpload::make('video_url')->disk('public')->directory('video')
                  ->label('Upload Video')
                  ->acceptedFileTypes(['video/mp4', 'video/avi', 'video/mov', 'video/wmv', 'video/flv', 'video/mkv', 'video/webm'])
                  ->maxSize(551200)
                  ->visibility('public')
                  ->afterStateUpdated(fn (callable $set, $state) => $set('mime', $state?->getMimeType())),
                  Forms\Components\FileUpload::make('thumbnail')->disk('public')->directory('thumbnail')
                  ->acceptedFileTypes(['image/png', 'image/webp', 'image/jpeg', 'image/jpg']),

                ])->columnSpan(1),

               Section::make('Other')->schema([
                  Forms\Components\TextInput::make('access')
                    ->maxLength(255),
                  Forms\Components\Select::make('status')
                    ->required()
                    ->options([
                        '0' => 'Invisible',
                        '1' => 'Visible'
                    ])
                    ->default(1),
               ])->columnSpan(2)->columns(2),
               Section::make('Category')->schema([
                  Forms\Components\Select::make('category_id')
                    ->label('Category')
                    ->required()
                    ->options(Category::all()->pluck('name', 'id'))
                    ->searchable()
               ])->columnSpan(1)
            ])->columns(3);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                // Tables\Columns\TextColumn::make('category_id')
                //     ->numeric()
                //     ->sortable(),
                Tables\Columns\TextColumn::make('title')
                    ->searchable(),
                Tables\Columns\ImageColumn::make('video_url')
                    ->label('video')
                    ->searchable(),
                Tables\Columns\ImageColumn::make('thumbnail')
                    ->searchable(),
                Tables\Columns\TextColumn::make('access')
                    ->searchable(),
                Tables\Columns\TextColumn::make('status')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('deleted_at')
                    ->dateTime()
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\TrashedFilter::make(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                    Tables\Actions\ForceDeleteBulkAction::make(),
                    Tables\Actions\RestoreBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListVideos::route('/'),
            'create' => Pages\CreateVideo::route('/create'),
            'edit' => Pages\EditVideo::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->withoutGlobalScopes([
                SoftDeletingScope::class,
            ])->where('user_id', auth()->user()->id);
    }
}