<?php

namespace App\Filament\App\Resources\CategoryResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\Section;
use App\Models\Category;

class VideosRelationManager extends RelationManager
{
    protected static string $relationship = 'videos';

    public function form(Form $form): Form
    {
        return $form
             ->schema([
                Section::make('Video Details')
                ->schema([
                   Forms\Components\TextInput::make('title')
                    ->required()
                    ->maxLength(255),
                   Forms\Components\Textarea::make('description')
                    ->columnSpanFull(),
                   Forms\Components\Textarea::make('short_desc')
                    ->columnSpanFull(),
                ])->columnSpan(2),

                Section::make('Video/Image')->schema([
                  Forms\Components\FileUpload::make('video_url')->disk('public')->directory('video')
                  ->label('Upload Video')
                  ->acceptedFileTypes(['video/mp4', 'video/avi', 'video/mov', 'video/wmv', 'video/flv', 'video/mkv', 'video/webm'])
                  ->maxSize(551200)
                  ->visibility('public')
                  ->afterStateUpdated(fn (callable $set, $state) => $set('mime', $state?->getMimeType())),
                  Forms\Components\FileUpload::make('thumbnail')->disk('public')->directory('thumbnail')
                  ->acceptedFileTypes(['image/png', 'image/webp', 'image/jpeg', 'image/jpg']),

                ])->columnSpan(1),
               Section::make('Other')->schema([
                  Forms\Components\TextInput::make('access')
                    ->maxLength(255),
                  Forms\Components\Select::make('status')
                    ->required()
                    ->options([
                        '0' => 'Invisible',
                        '1' => 'Visible'
                    ])
                    ->default(1),
               ])->columnSpan(2)->columns(2),
               Section::make('Category')->schema([
                  Forms\Components\Select::make('category_id')
                    ->label('Category')
                    ->required()
                    ->options(Category::all()->pluck('name', 'id'))
                    ->searchable()
               ])->columnSpan(1)
            ])->columns(3);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('title')
            ->columns([
                Tables\Columns\TextColumn::make('title'),
            ])
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}