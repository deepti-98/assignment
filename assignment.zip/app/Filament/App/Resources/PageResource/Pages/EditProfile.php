<?php

namespace App\Filament\App\Resources\PageResource\Pages;

use App\Filament\App\Resources\PageResource;
use Filament\Resources\Pages\Page;

class EditProfile extends Page
{
    protected static string $resource = PageResource::class;

    protected static string $view = 'filament.app.resources.page-resource.pages.edit-profile';
}
