<?php

namespace App\Filament\App\Resources\CustomResource\Pages;

use App\Filament\App\Resources\CustomResource;
use App\Filament\App\Resources\UserResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class Profile extends EditRecord
{
    protected static string $resource = UserResource::class;
}