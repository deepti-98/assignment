<?php

namespace App\Filament\Resources\TeacherResource\Pages;

use App\Filament\Resources\TeacherResource;
use App\Filament\Resources\TeacherResource\Widgets\TeacherOverview;
use Filament\Actions;
use Filament\Forms\Components\Builder;
use Filament\Forms\Components\DatePicker;
use Filament\Resources\Pages\ListRecords;
use Filament\Tables\Filters\Filter;

class ListTeachers extends ListRecords
{
    protected static string $resource = TeacherResource::class;

   protected $listeners = ['setStatusFilter' => 'updateTableFilters', 'setStatusFilter1' => 'updateTableFilters1','setStatusFilterTwo' => 'updateTableFiltersTwo'];

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
     protected function getActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }

    protected function getHeaderWidgets(): array
    {
        return [
            TeacherOverview::class
        ];
    }

    public function updateTableFilters(string $filter) {
         //$this->tableFilters['status']['value'] = $filter;
         return redirect()->to('admin/teacher?tableFilters[status][value]=');
    }
     public function updateTableFilters1(string $filter) {
         //$this->tableFilters['status']['value'] = $filter;
         return redirect()->to('admin/teacher?tableFilters[status][value]=1');
    }
     public function updateTableFiltersTwo(string $filter) {
         //$this->tableFilters['status']['value'] = $filter;
         return redirect()->to('admin/teacher?tableFilters[status][value]=0');
    }

    //  protected function getTableFilters(): array
    // {
    //     return [
    //         Filter::make('created_at')
    //             ->form([
    //                 DatePicker::make('created_from'),
    //                 DatePicker::make('created_until'),
    //             ])
    //             ->query(function (Builder $query, array $data): Builder {
    //                 return $query
    //                     ->when(
    //                         $data['created_from'],
    //                         fn(Builder $query, $date): Builder => $query->whereDate('created_at', '>=', $date),
    //                     )
    //                     ->when(
    //                         $data['created_until'],
    //                         fn(Builder $query, $date): Builder => $query->whereDate('created_at', '<=', $date),
    //                     );
    //             })
    //     ];
    // }

}