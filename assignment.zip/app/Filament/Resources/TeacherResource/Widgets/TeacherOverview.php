<?php

namespace App\Filament\Resources\TeacherResource\Widgets;

use App\Filament\Resources\TeacherResource\Pages\ListTeachers;
use App\Models\Teacher;
use App\Models\User;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use Illuminate\Support\Facades\Cache;

class TeacherOverview extends BaseWidget
{
    //protected $listeners = ['setStatusFilter' => 'updateTableFilters'];

    protected function getStats(): array
    {
        Cache::remember('teacher', '60ttl', function(){
            return User::where('role_id', 0)->count();
        });
        Cache::remember('teacher_approve', '60ttl', function(){
            return  User::where('role_id', 0)->where('status', 1)->count();
        });
        Cache::remember('teacher_pending', '60ttl', function(){
            return  User::where('role_id', 0)->where('status', 0)->count();
        });
        return [
            Stat::make('Registered', Cache::get('teacher'))->description('Total Teacher')
            ->chart([7, 2, 10, 3, 15, 4, 17])
            ->color('success')
             ->extraAttributes([
                'class' => 'cursor-pointer',
                'wire:click' => "\$dispatch('setStatusFilter', { filter: '' })",
            ]),
            Stat::make('Approved', Cache::get('teacher_approve'))->description('Approved Teacher')
            ->chart([7, 2, 10, 3, 15, 4, 17])
            ->color('success')
             ->extraAttributes([
                'class' => 'cursor-pointer',

                'wire:click' => "\$dispatch('setStatusFilter1', { filter: '1' })",
            ]),
            Stat::make('Pending',Cache::get('teacher_pending'))->description('Pending Teacher')
            ->chart([7, 2, 10, 3, 15, 4, 17])
            ->color('success')
             ->extraAttributes([
                'class' => 'cursor-pointer',

                'wire:click' => "\$dispatch('setStatusFilterTwo', { filter: '1' })",
            ]),
        ];
    }



}