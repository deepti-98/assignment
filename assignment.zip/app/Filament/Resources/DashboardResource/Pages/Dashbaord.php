<?php

namespace App\Filament\Pages;

use App\Filament\Widgets;
use Filament\Facades\Filament;

use App\Filament\Resources\CustomerResource\Widgets\UserOverview;
use App\Filament\Resources\DashboardResource\Widgets\DashboardChart;
use App\Filament\Resources\DashboardResource\Widgets\UserChart;
use App\Filament\Resources\TeacherResource\Widgets\TeacherOverview;

use Filament\Pages\Dashboard as BasePage;

class Dashbaord extends BasePage
{

     public function getHeaderWidgets(): array
     {
        return [ TeacherOverview::class,
                  UserOverview::class,
                  DashboardChart::class,
                  UserChart::class
               ];
     }
}