<?php

namespace App\Filament\Resources\DashboardResource\Widgets;

use App\Models\Teacher;
use App\Models\User;
use Filament\Forms\Components\Builder;
use Filament\Forms\Components\DatePicker;
use Filament\Tables\Filters\Filter;
use Filament\Widgets\ChartWidget;
use Flowframe\Trend\Trend;
use Flowframe\Trend\TrendValue;

class DashboardChart extends ChartWidget
{
    protected static ?string $heading = 'Teachers Chart';

    public ?string $filter = 'month';

    protected function getData(): array
    {
        $activeFilter = $this->filter;
        if($activeFilter == "year"){
            $data = Trend::model(User::class)
                   ->between(
                        start: now()->startOfYear(),
                        end: now()->endOfYear(),
                        )

                   ->perMonth()
                   ->count();
           }elseif($activeFilter == "month"){
               $data = Trend::model(User::class)
                   ->between(
                        start: now()->startOfMonth(),
                        end: now()->endOfMonth(),
                        )
                   ->perDay()
                   ->count();
           }elseif($activeFilter == "week"){
               $data = Trend::model(Teacher::class)
                   ->between(
                        start: now()->startOfWeek(),
                        end: now()->endOfWeek(),
                        )
                   ->perDay()
                   ->count();
           }elseif($activeFilter == "today"){
               $data = Trend::model(Teacher::class)
                   ->between(
                        start: now()->startOfDay(),
                        end: now()->endOfDay(),
                        )
                   ->perHour()
                   ->count();
           }

        return [
            'datasets' => [
                [
                    'label' => 'Total',
                    'data' => $data->map(fn (TrendValue $value) => $value->aggregate),
                ],
            ],
            'labels' => $data->map(fn (TrendValue $value) => $value->date),
        ];
    }

    protected function getType(): string
    {
        return 'bar';
    }

    protected function getFilters(): ?array
     {
       return [
        'today' => 'Today',
        'week' => 'Last week',
        'month' => 'Last month',
        'year' => 'This year',
      ];
    }

        protected function getTableFilters(): array
    {
        return [
            Filter::make('created_at')
                ->form([
                    DatePicker::make('created_from'),
                    DatePicker::make('created_until'),
                ])
                ->query(function (Builder $query, array $data): Builder {
                    return $query
                        ->when(
                            $data['created_from'],
                            fn(Builder $query, $date): Builder => $query->whereDate('created_at', '>=', $date),
                        )
                        ->when(
                            $data['created_until'],
                            fn(Builder $query, $date): Builder => $query->whereDate('created_at', '<=', $date),
                        );
                })
        ];
    }

}