<?php

namespace App\Filament\Resources\DashboardResource\Widgets;

use App\Models\Customer;
use Filament\Widgets\ChartWidget;
use Flowframe\Trend\Trend;
use Flowframe\Trend\TrendValue;

class UserChart extends ChartWidget
{
    protected static ?string $heading = 'Users Chart';

    public ?string $filter = 'month';

    protected function getData(): array
    {
        $activeFilter = $this->filter;
        if($activeFilter == "year"){
            $data = Trend::model(Customer::class)
                   ->between(
                        start: now()->startOfYear(),
                        end: now()->endOfYear(),
                        )
                   ->perMonth()
                   ->count();
           }elseif($activeFilter == "month"){
               $data = Trend::model(Customer::class)
                   ->between(
                        start: now()->startOfMonth(),
                        end: now()->endOfMonth(),
                        )
                   ->perDay()
                   ->count();
           }elseif($activeFilter == "week"){
               $data = Trend::model(Customer::class)
                   ->between(
                        start: now()->startOfWeek(),
                        end: now()->endOfWeek(),
                        )
                   ->perDay()
                   ->count();
           }elseif($activeFilter == "today"){
               $data = Trend::model(Customer::class)
                   ->between(
                        start: now()->startOfDay(),
                        end: now()->endOfDay(),
                        )
                   ->perHour()
                   ->count();
           }
        return [
            'datasets' => [
                [
                    'label' => 'Total',
                    'data' => $data->map(fn (TrendValue $value) => $value->aggregate),
                ],
            ],
            'labels' => $data->map(fn (TrendValue $value) => $value->date),
        ];
    }

    protected function getType(): string
    {
        return 'bar';
    }

    protected function getFilters(): ?array
     {
       return [
        'today' => 'Today',
        'week' => 'Last week',
        'month' => 'Last month',
        'year' => 'This year',
      ];
    }
}