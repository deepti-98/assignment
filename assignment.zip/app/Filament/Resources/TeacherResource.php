<?php

namespace App\Filament\Resources;

use App\Filament\Resources\TeacherResource\Widgets\TeacherOverview;
use App\Filament\Resources\UserResource\Pages;
use App\Filament\Resources\UserResource\RelationManagers;
use App\Models\User;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\SpatieTagsInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\SpatieTagsColumn;
use Filament\Tables\Enums\FiltersLayout;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Support\Str;
use Filament\Tables\Filters\Filter;
use Spatie\Tags\Tag;
class TeacherResource extends Resource
{
    protected static ?string $model = User::class;

    protected static ?string $navigationLabel = 'SuperAdmin';

    protected static ?string $slug = "teacher";

    protected static ?string $navigationIcon = 'heroicon-o-user';



    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Profile')
                ->description('')
                ->schema([
                   Forms\Components\TextInput::make('name')
                    ->maxLength(255),
                    Forms\Components\TextInput::make('email')
                    ->email()
                    ->maxLength(255),
                ])->columnSpan(1),
                Section::make('Profile')
                ->description('')
                ->schema([
                   Forms\Components\Select::make('status')
                   ->options(['1'=>'Approved','0'=>'Pending', '2' => 'Rejected']),
                ])->columnSpan(1),

                Section::make('Your Details')
                ->schema([

                     Forms\Components\TextInput::make('address')
                    ->maxLength(255),
                Forms\Components\TextInput::make('phone')
                    ->tel()
                    ->maxLength(255),
                Forms\Components\TextInput::make('skype_id')
                    ->maxLength(255),
                Forms\Components\TextInput::make('teaching_experience')
                    ->maxLength(255),
                Forms\Components\TextInput::make('teaching_history')
                    ->maxLength(255),
                Forms\Components\FileUpload::make('upload_resume'),
                Forms\Components\TextInput::make('video_link')
                    ->maxLength(255),
                Forms\Components\TextInput::make('your_website')
                    ->maxLength(255),
                Forms\Components\TextInput::make('teacher_training_organization')
                    ->maxLength(255),
                Forms\Components\FileUpload::make('profile_pic')
                     ->disk('public'),
                Forms\Components\TextInput::make('password')
                     ->maxLength(255),
                ])->columnSpan(1),
                Section::make('Page Setup')
                ->schema([
                    Forms\Components\TextInput::make('title')
                    ->maxLength(255)
                    ->live(onBlur: true)
                    ->unique(ignoreRecord: true)
                    ->afterStateUpdated(function(string $operation, $state, Forms\Set $set) {
                        $set('slug', Str::slug($state));
                    }),
                Forms\Components\TextInput::make('slug')
                ->disabled()
                ->dehydrated()
                ->unique(User::class, 'slug', ignoreRecord: true),
                   Forms\Components\Textarea::make('desc')
                    ->columnSpanFull(),
                Forms\Components\Textarea::make('short_desc')
                    ->columnSpanFull(),
                Forms\Components\FileUpload::make('featured_image')
                    ->image(),
                Forms\Components\FileUpload::make('featured_video'),
                ])->columnSpan(1)
            ])->columns(2);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->searchable(),
                Tables\Columns\TextColumn::make('email')
                    ->searchable(),
            ])
            ->filters([
                SelectFilter::make('status')->options([
                    0 => 'Pending',
                    1 => "Approved"
                ]),
            ],layout: FiltersLayout::AboveContentCollapsible)
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => TeacherResource\Pages\ListTeachers::route('/'),
            'create' => TeacherResource\Pages\CreateTeacher::route('/create'),
            'edit' => TeacherResource\Pages\EditTeacher::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->withoutGlobalScopes([
                SoftDeletingScope::class,
            ])->where('role_id', 0);
    }

    public static function getNavigationBadge(): ?string
    {
        return User::where('role_id', 0)->count();
    }



}