<?php

namespace App\Filament\Resources;

use App\Filament\Resources\HomeResource\Pages;
use App\Filament\Resources\HomeResource\RelationManagers;
use App\Models\Category;
use App\Models\Home;
use App\Models\Video;
use Filament\Forms;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\SpatieTagsInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Actions\AttachAction;
use Filament\Tables\Columns\SpatieTagsColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Spatie\Tags\Tag;

class HomeResource extends Resource
{
    protected static ?string $model = Video::class;

    protected static ?string $navigationLabel = "Classes";

    protected static ?string $navigationGroup = "Website";

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Video Details')
                ->schema([
                   Forms\Components\TextInput::make('title')
                    ->required()
                    ->maxLength(255),
                   Forms\Components\Textarea::make('description')
                    ->columnSpanFull(),
                   Forms\Components\Textarea::make('short_desc')
                    ->columnSpanFull(),
                ])->columnSpan(2),

                Section::make('Video/Image')->schema([
                  Forms\Components\FileUpload::make('video_url')->disk('public')->directory('video')
                  ->label('Upload Video')
                  ->acceptedFileTypes(['video/mp4', 'video/avi', 'video/mov', 'video/wmv', 'video/flv', 'video/mkv', 'video/webm'])
                  ->maxSize(551200)
                  ->visibility('public')
                  ->afterStateUpdated(fn (callable $set, $state) => $set('mime', $state?->getMimeType())),
                  Forms\Components\FileUpload::make('thumbnail')->disk('public')->directory('thumbnail')
                  ->acceptedFileTypes(['image/png', 'image/webp', 'image/jpeg', 'image/jpg']),

                ])->columnSpan(1),
               Section::make('Other')->schema([
                  Forms\Components\TextInput::make('access')
                    ->maxLength(255),
                  Forms\Components\Select::make('status')
                    ->required()
                    ->options([
                        '0' => 'Invisible',
                        '1' => 'Visible'
                    ])
                    ->default(1),

               ])->columnSpan(2)->columns(2),
               Section::make('Category')->schema([
                  Forms\Components\Select::make('category_id')
                    ->label('Category')
                    ->required()
                    ->options(Category::all()->pluck('name', 'id'))
                    ->searchable(),
                 SpatieTagsInput::make('tags')
                    ->type('video')
                    ->splitKeys(['Tab', ' '])
                     ->suggestions([
                       'classes',
                     ])
               ])->columnSpan(1)
            ])->columns(3);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
               Tables\Columns\TextColumn::make('title')
                    ->searchable(),
                Tables\Columns\ImageColumn::make('video_url')
                    ->label('video')
                    ->searchable(),
                Tables\Columns\ImageColumn::make('thumbnail')
                    ->searchable(),
                Tables\Columns\TextColumn::make('status')
                    ->numeric()
                    ->sortable(),
                 Tables\Columns\IconColumn::make('status')
                    ->boolean(),
                //SpatieTagsColumn::make('tags'),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->headerActions(
                [
                    Tables\Actions\AttachAction::make()
                    ->form(fn(AttachAction $action):array=> [
                         Select::make('tad_id')->options(Video::all()->pluck('title', 'id'))
                    ])

                ]
            )
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //RelationManagers\VideosRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListHomes::route('/'),
            'create' => Pages\CreateHome::route('/create'),
            'edit' => Pages\EditHome::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->withoutGlobalScopes([
                SoftDeletingScope::class,
            ])->withAnyTags(['classes'], 'video');
    }
}