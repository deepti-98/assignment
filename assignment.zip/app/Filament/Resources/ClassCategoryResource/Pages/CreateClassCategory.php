<?php

namespace App\Filament\Resources\ClassCategoryResource\Pages;

use App\Filament\Resources\ClassCategoryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateClassCategory extends CreateRecord
{
    protected static string $resource = ClassCategoryResource::class;

    protected function getRedirectUrl(): string
    {
        return static::getResource()::getUrl('index');
    }
}