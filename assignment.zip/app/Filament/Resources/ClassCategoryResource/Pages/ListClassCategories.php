<?php

namespace App\Filament\Resources\ClassCategoryResource\Pages;

use App\Filament\Resources\ClassCategoryResource;
use App\Filament\Resources\ClassCategoryResource\Widgets\ClassCategoryWidget;
use App\Models\ClassCategory;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListClassCategories extends ListRecords
{
    protected static string $resource = ClassCategoryResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }

    protected function getHeaderWidgets(): array
    {
        return [
            ClassCategoryWidget::class
        ];

    }
}