<?php

namespace App\Filament\Resources\FinancialResource\Pages;

use App\Filament\Resources\FinancialResource;
use App\Filament\Resources\FinancialResource\Widgets\FinanceChart;
use Filament\Resources\Pages\Page;

class Financial extends Page
{
    protected static string $resource = FinancialResource::class;

    protected static string $view = 'filament.resources.financial-resource.pages.financial';

     public function getHeaderWidgets():array{
        return [
            FinanceChart::class
        ];
    }
}