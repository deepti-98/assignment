<?php

namespace App\Filament\Resources\FinancialResource\Pages;

use App\Filament\Resources\FinancialResource;
use App\Filament\Resources\FinancialResource\Widgets\FinanceChart;
use Filament\Resources\Pages\Page;

class Content extends Page
{
    protected static string $resource = FinancialResource::class;

    protected static string $view = 'filament.resources.financial-resource.pages.content';

    // public function getHeaderWidgets():array{
    //     return [
    //         FinanceChart::class
    //     ];
    // }
}