<?php

namespace App\Filament\Resources\FinancialResource\Pages;

use App\Filament\Resources\FinancialResource;
use App\Filament\Resources\FinancialResource\Widgets\SubscriberChart;
use Filament\Resources\Pages\Page;

class Subscriber extends Page
{
    protected static string $resource = FinancialResource::class;

    protected static string $view = 'filament.resources.financial-resource.pages.subscriber';

    public function getHeaderWidgets():array
     {
        return [
              SubscriberChart::class
        ];

     }
}