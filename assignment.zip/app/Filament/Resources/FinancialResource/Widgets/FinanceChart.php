<?php

namespace App\Filament\Resources\FinancialResource\Widgets;

use App\Models\Teacher;
use Filament\Widgets\ChartWidget;
use Flowframe\Trend\Trend;
use Flowframe\Trend\TrendValue;

class FinanceChart extends ChartWidget
{
    protected static ?string $heading = 'Gross Revenue';

    public ?string $filter = 'year';

    protected int | string | array $columnSpan = 12;

    protected static ?string $maxHeight = '300px';

    protected function getData(): array
    {
        $activeFilter = $this->filter;
        if($activeFilter == "year"){
            $data = Trend::model(Teacher::class)
                   ->between(
                        start: now()->startOfYear(),
                        end: now()->endOfYear(),
                        )
                   ->perMonth()
                   ->count();
           }elseif($activeFilter == "month"){
               $data = Trend::model(Teacher::class)
                   ->between(
                        start: now()->startOfMonth(),
                        end: now()->endOfMonth(),
                        )
                   ->perDay()
                   ->count();
           }elseif($activeFilter == "week"){
               $data = Trend::model(Teacher::class)
                   ->between(
                        start: now()->startOfWeek(),
                        end: now()->endOfWeek(),
                        )
                   ->perDay()
                   ->count();
           }elseif($activeFilter == "today"){
               $data = Trend::model(Teacher::class)
                   ->between(
                        start: now()->startOfDay(),
                        end: now()->endOfDay(),
                        )
                   ->perHour()
                   ->count();
           }

        return [
             'datasets' => [
                [
                    'label' => 'Total',
                    'data' => $data->map(fn (TrendValue $value) => $value->aggregate),
                ],
            ],
            'labels' => $data->map(fn (TrendValue $value) => $value->date),
        ];

    }

    protected function getType(): string
    {
        return 'line';
    }
    protected function getFilters(): ?array
    {
    return [
        'today' => 'Today',
        'week' => 'Last week',
        'month' => 'Last month',
        'year' => 'This year',
    ];
    }

}