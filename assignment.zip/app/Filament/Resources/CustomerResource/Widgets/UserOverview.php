<?php

namespace App\Filament\Resources\CustomerResource\Widgets;

use App\Models\Customer;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class UserOverview extends BaseWidget
{
    protected function getStats(): array
    {
        $total = Customer::all()->count();
        return [
            Stat::make('Registered', $total)->description('Total User')
            ->chart([7, 2, 10, 3, 15, 4, 17])
            ->color('success')
            ->extraAttributes([
                'class' => 'cursor-pointer',
                'wire:click' => "\$dispatch('setStatusFilterCustomer', { filter: 'processed' })",
            ]),
            Stat::make('Free Trial', $total)->description('Trial User')
            ->chart([7, 2, 10, 3, 15, 4, 17])
            ->color('success')
             ->extraAttributes([
                'class' => 'cursor-pointer',
                'wire:click' => "\$dispatch('setStatusFilterCustomer', { filter: 'processed' })",
            ]),
            Stat::make('Paid', 0)->description('Paid User')
            ->chart([7, 2, 10, 3, 15, 4, 17])
            ->color('success')
             ->extraAttributes([
                'class' => 'cursor-pointer',
                'wire:click' => "\$dispatch('setStatusFilterCustomerNone', { filter: 'processed' })",
            ]),
        ];
    }



}