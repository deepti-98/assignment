<?php

namespace App\Filament\Resources\CustomerResource\Pages;

use App\Filament\Resources\CustomerResource;
use App\Filament\Resources\CustomerResource\Widgets\UserOverview;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListCustomers extends ListRecords
{
    protected static string $resource = CustomerResource::class;

    protected $listeners = ['setStatusFilterCustomer' => 'updateTableFilters', 'setStatusFilterCustomerNone' => 'updateTableFiltersNone'];

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
    protected function getHeaderWidgets(): array
    {
        return [
            UserOverview::class
        ];
    }

    public function updateTableFilters(string $filter) {
         return redirect()->to('admin/customers?tableFilters[status][value]=');
    }

    public function updateTableFiltersNone(string $filter) {
         return redirect()->to('admin/customers?tableFilters[status][value]=10');
    }

}