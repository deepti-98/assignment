<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Jobs\SendEmail;
use App\Models\Image;
use App\Models\Teacher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;
use App\Models\User;
use Exception;

class TeacherController extends Controller
{
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth:api', ['except' => ['login']]);
    // }

    /**
     * Get a JWT via given credentials.
     *
     * @return \Illuminate\Http\JsonResponse
     */

     public function index(Request $req){
        try{
            if($req['type']){
                $type = explode(',', $req->type);
                $data = User::where('role_id', 0)->withAllTags($type)->where('status', 1)->get();
                return response()->json(['status' => 200, 'data' => $data]);
            }else{
                $data = User::where('role_id', 0)->where('status', 1)->get();
                return response()->json(['status' => 200, 'data' => $data]);
            }

        }catch (Exception $e){
           return response()->json(['status'=> 400, 'Error'=> $e]);
        }
     }

     public function single(Request $request, $slug){
        try{
           $data = User::where('role_id', 0)->where('status', 1)->where('slug', $slug)->first();
           return response()->json(['status' => 200, 'data' => $data]);
        }catch (Exception $e){
           return response()->json(['status'=> 400, 'Error'=> $e]);
        }
     }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string',
            'email' => 'required',
            'password' => 'required',
            // Add validation rules for other fields here
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 400);
        }

        // Handle picture upload
        $uniqueFilename = null;
        if ($request->hasFile('picture')) {
            $file = $request->file('picture');
            $originalName = $file->getClientOriginalName();
            $uniqueFilename = time() . '_' . rand(1000, 9999) . '_' . $originalName;
            $picturePath = $file->storeAs('public/picture', $uniqueFilename);
        }
        // Create the teacher record


        $teacher = Teacher::create([
            'first_name' => $request->input('first_name'),
            'middle_name' => $request->input('middle_name'), // Remove if not needed
            'last_name' => $request->input('last_name'), // Remove if not needed
            'email' => $request->input('email'),
            'phone' => $request->input('phone'),
            'picture' => $uniqueFilename,
            'address' => $request->input('address'),
            'skype_id' => $request->input('skype_id'),
            'teaching_experience' => $request->input('teaching_experience'),
            'teaching_history' => $request->input('teaching_history'),
            'teacher_training' => $request->input('teacher_training'),
            'video_link' => $request->input('video_link'),
            'your_website' => $request->input('your_website'),
            'password' => Hash::make($request->input('password')), // Hash the password
        ]);

        if($teacher){
           $teach = Teacher::where('email', $request->input('email'))->first();
           User::create([
            'name'=> $request->input('first_name') ." ".$request->input('last_name'),
            'email' => $request->input('email'),
            'role' => 'teacher',
            'teacher_id' => $teach->id,
            'password' => Hash::make($request->input('password'))
          ]);
        }

        // Create the associated image if uploaded
        if ($uniqueFilename) {
            Image::create([
                'teacher_id' => $teacher->id, // Associate the image with the teacher
                'name' => $uniqueFilename,
                'path' => $picturePath,
            ]);
        }
        $response = [
            'message' => 'Teacher Successfully Registered',
            'Teacher' => $teacher
        ];

        // Dispatch the email job after sending the response
        dispatch(new SendEmail($teacher));
        dispatch(new SendEmail(['email' => 'smruti.thetechnovate@gmail.com']));

        return response()->json($response);
    }

    public function login()
    {
        $credentials = request(['email', 'password']);
        // Check if the user's status is equal to 1
        $user = Teacher::where('email', $credentials['email'])
            // ->where('status','approved')
            ->first();
        if (!$user || !Hash::check($credentials['password'], $user->password)) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
        if (!$token = auth()->guard('teacher-api')->attempt($credentials)) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
        return $this->respondWithToken($user, $token);
    }
    protected function respondWithToken($user, $token)
    {
        return response()->json([
            'authUser' => $user,
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60
        ]);
    }

    public function show($id)
    {
        $teacher = Teacher::find($id);
        if (!$teacher) {
            return response()->json(['message' => 'User not found'], 404);
        }
        return response()->json($teacher);
    }
    public function showImage($id)
    {
        $image = Image::where('teacher_id', $id)->first(); // Find the image by teacher_id
        if (!$image) {
            return response()->json(['message' => 'User not found'], 404);
        }
        return response()->json($image);
    }

    public function update(Request $request, $id)
    {
        //return $id;
        //$id = Route::current()->parameter('id');
        // dd($teacher);

        $teacherData = $request->only([
            'first_name' => $request->first_name,
            'middle_name' =>  $request->middle_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'password' => $request->password, // Corrected 'password' field
            'phone' => $request->phone,
            'address' => $request->address,
            'picture' => $request->picture,
            'upload_resume' => $request->resume,
            'skype_id' => $request->skype_id,
            'teaching_experience' => $request->teaching_experience,
            'teaching_history'  => $request->teaching_history,
            'teacher_training' => $request->teacher_training,
            'video_link' => $request->video_link,
            'your_website' => $request->your_website,
            // 'teacher_training_organization' => $request->your_website,
        ]);

        if ($request->hasFile('resume')) {
            $file = $request->file('resume');
            $uploadResumePath = $file->store('resumes');
            $teacherData['upload_resume'] = basename($uploadResumePath);
        }

        if ($request->hasFile('picture')) {
            $file = $request->file('picture');
            $picturePath = $file->store('picture', 'public'); // 'public' is the disk name

            // dd($picturePath);
            // $picturePath = $file->store('pictures');
            $teacherData['picture'] = basename($picturePath);
        }

        if (!empty($request->password)) {
            $passwordHash = Hash::make($request->password);
            $teacherData['password'] = $passwordHash;
        }

        $teacher = Teacher::find($id);
        $teacher->update($teacherData);
        if ($teacher) {
            // Update the model's attributes and save the changes
            $teacher->update($teacherData);
            return response()->json(['message' => 'Teacher updated successfully']);
        } else {
            return response()->json(['message' => 'Teacher not found'], 404);
        }
        // return response()->json([
        //     'message' => 'Teacher Successfully Updated',
        //     'teacher' => $teacher
        // ]);
    }

    public function updateImage(Request $request)
    {
        $id = Route::current()->parameter('id');
        if ($request->hasFile('picture')) {
            $file = $request->file('picture');
            $originalName = $file->getClientOriginalName();
            $uniqueFilename = time() . '_' . rand(1000, 9999) . '_' . $originalName;
            $picturePath = $file->storeAs('picture', $uniqueFilename, 'public');
            // Update the image data
            $imageData = [
                'name' => $uniqueFilename,
                'path' => $picturePath,
            ];
            $image = Image::where('teacher_id', $id)->first(); // Find the image by teacher_id
            if ($image) {
                // Delete the existing file from storage
                Storage::disk('public')->delete($image->path);
                // Update the model's attributes and save the changes
                $image->update($imageData);
                return response()->json(['message' => 'Image updated successfully']);
            } else {
                return response()->json(['message' => 'Image not found'], 404);
            }
        } else {
            return response()->json(['message' => 'No picture provided'], 400);
        }
    }

    /**
     * Get the authenticated User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    // public function profile()
    // {
    //     return response()->json(auth()->guard('teacher-api')->user());
    // }

    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        auth()->logout();
        return response()->json(['message' => 'Successfully logged out']);
    }
    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    // public function refresh()
    // {
    //     return $this->respondWithToken(auth()->refresh());
    // }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
}