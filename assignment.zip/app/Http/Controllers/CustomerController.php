<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    protected $customer;
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        $customer = Customer::where('email', $request->email)->first();

        if (!$token = auth()->guard('customer-api')->attempt($credentials)) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        return response()->json(['token'=> $this->respondWithToken($token), 'user' => $customer]);
    }

    /**
     * Store a newly created resource in storage.
     */

    public function me()
    {
        return response()->json(auth()->user());
    }

    /**
     * Store a newly created resource in storage.
     */

    public function logout()
    {
        auth()->logout();

        return response()->json(['status'=> 200, 'message' => 'Successfully logged out']);
    }

    /**
     * Store a newly created resource in storage.
     */

    protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $credentials = $request->only('email', 'password');
        $customer = new Customer();
        try {
           $customer->full_name = $request->full_name;
           $customer->email = $request->email;
           $customer->phone = $request->phone;
           $customer->password = Hash::make($request->password);
           $response = $customer->save();
        if($response){
             $customer = Customer::where('email', $customer->email)
            ->first();
            if (!$token = auth()->guard('customer-api')->attempt($credentials)) {
               return response()->json(['error' => 'Unauthorized'], 401);
            }
            return response()->json(['status'=> 200, 'user'=>  $customer , 'token' => $this->respondWithToken($token)]);
         }else{

         }

        } catch (Exception $e){
            return response()->json(['status'=> 400, 'message' => $e]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Customer $customer)
    {

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Customer $customer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
           if($customer = Customer::find($id)){
              $user = $customer->update([
                 'full_name' => $request->full_name,
                 'email' => $request->email,
                 'phone' => $request->phone
               ]);
            if($user){
                return response()->json(['status' => 200, 'data' => $customer]);
            }else{
                return response()->json(['status' => 201, 'message' => 'Error']);
            }
           }else{
              return response()->json(['status' => 400, 'message' => 'This user not exist']);
           }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Customer $customer)
    {
        //
    }
}