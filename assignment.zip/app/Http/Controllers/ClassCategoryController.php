<?php

namespace App\Http\Controllers;

use App\Models\ClassCategory;
use GuzzleHttp\Psr7\Response;
use Illuminate\Http\Request;

class ClassCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories = ClassCategory::where('parent_id', -1)->with('children')->get();
        return Response()->json(['status' => 200, 'data' => $categories]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ClassCategory $classCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ClassCategory $classCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ClassCategory $classCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ClassCategory $classCategory)
    {
        //
    }
}