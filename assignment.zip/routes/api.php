<?php

use App\Http\Controllers\ClassCategoryController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\TeacherController;
use App\Http\Controllers\VideoController;
use App\Http\Resources\SubscriptionResource;
use App\Models\Subscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
Route::get('teacher/single/{slug}', [App\Http\Controllers\TeacherController::class, 'single']);
Route::get('teacher/all', [App\Http\Controllers\TeacherController::class, 'index']);
Route::post('teacher/Register', [App\Http\Controllers\TeacherController::class, 'Register']);
Route::post('teacher/login', [App\Http\Controllers\TeacherController::class, 'login']);

Route::group(['middleware' => 'teacher:teacher-api', 'prefix' => 'teacher'], function ($router) {
    Route::get('profile/{id}', [App\Http\Controllers\TeacherController::class, 'show']);
    Route::get('image/{id}', [App\Http\Controllers\TeacherController::class, 'showImage']);
    Route::post('logout', [App\Http\Controllers\TeacherController::class, 'logout']);
    // Route::post('profile', [App\Http\Controllers\TeacherController::class, 'profile']);
    Route::post('updateProfile/{id}', [App\Http\Controllers\TeacherController::class, 'update']);
    Route::post('updateImage/{id}', [App\Http\Controllers\TeacherController::class, 'updateImage']);
});

// website public api

Route::get('/subscription', function(){
    $subscription = Subscription::all();
    return SubscriptionResource::collection($subscription);
});

Route::get('/subscription/{slug}', function($slug){
   $subscription = Subscription::where('slug', $slug)->get();
   return SubscriptionResource::collection($subscription);
});

// customer api
Route::post('/customer/register', [App\Http\Controllers\CustomerController::class, 'store']);
Route::post('/customer/update/{id}', [App\Http\Controllers\CustomerController::class, 'update']);
//Route::post('/customer/login', [App\Http\Controllers\CustomerController::class, 'login']);
Route::post('/customer/login', [App\Http\Controllers\CustomerController::class, 'login']);
Route::group(['prefix' => 'customer','middleware' => ['assign.guard:customer-api','jwt.auth']],function ()
{

});

Route::post('/customer/logout', [App\Http\Controllers\CustomerController::class, 'logout']);

//video route

Route::get('video', [App\Http\Controllers\VideoController::class, 'index']);

Route::get('/class-category', [ClassCategoryController::class, 'index']);

// blog route
Route::get('/blog', [App\Http\Controllers\PostController::class, 'index']);
// blog route
Route::get('/page', [App\Http\Controllers\PageController::class, 'index']);
