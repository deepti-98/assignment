<!DOCTYPE html>
<html>
<head>
    <title>Account Approval</title>
</head>
<body>
    <h1>Account Approval Notification</h1>
    <p>Dear User,</p>
    <p>Your account registration request is pending approval by our administrators.</p>
    <p>Please wait patiently while we review your information. This process typically takes a short amount of time, and we will notify you via email once your account is approved.</p>
    <p>If you have any urgent questions or require immediate assistance, please don't hesitate to contact our support team at support@example.com.</p>
    <p>Thank you for choosing our platform, and we appreciate your patience during this process.</p>
    <p>Sincerely,</p>
    <p>The Pilates Team</p>
</body>
</html>
