<x-filament-panels::page>
   <p>finantial period</p>
</x-filament-panels::page>
