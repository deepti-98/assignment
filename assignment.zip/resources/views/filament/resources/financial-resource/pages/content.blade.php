<x-filament-panels::page>
    <div style="display: grid; grid-template-columns: auto auto auto auto auto auto; column-gap: 5px">
       <div style="grid-column: 1 / 3" class="p-6 fi-section rounded-sm bg-white shadow-sm ring-1 ring-gray-950/5 dark:bg-gray-900 dark:ring-white/10 fi-wi-chart">
            <ul>
                <li style="margin-bottom: 8px"><a href="#">Watch time</a></li>
                <li style="margin-bottom: 8px"><a href="#">Views</a></li>
                <li style="margin-bottom: 8px"><a href="#">Videos</a></li>
            </ul>
        </div>
        <div style="grid-column: 3 / 6">
            @livewire(App\Filament\Resources\FinancialResource\Widgets\ViewsChart::class)
        </div>
    </div>
</x-filament-panels::page>
