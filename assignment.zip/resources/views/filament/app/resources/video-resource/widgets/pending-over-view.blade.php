<x-filament-widgets::widget>
    <x-filament::section>
                <div class="card"
                  style=""
                  style="
                    background-color: white;
                    padding: 20px;
                    border-radius: 10px;
                    box-shadow: rgba(49, 52, 64, 0.2) 0px 2px 12px;
                    height: 400px;
                    width: 100%;
                    position: relative;
                    padding: 0 100px;
                    "
                >
                  <div
                    style="
                      position: absolute,
                      top: 50%,
                      left: 50%,
                      transform: translate(-50%, -50%),
                      text-lign: center,
                    "
                  >
                    <h2 className="text-center text-danger" style="text-align:center; font-size: 20px;" >Pending</h2>
                    <h4 className="py-3" style="text-align: center">
                      Our dedicated team of yoga experts will carefully review
                      your application to verify your qualifications and assess
                      your readiness to become a certified yoga teacher.
                    </h4>
                    <h4 className="text-primary" style="text-align: center">It will take 4-5 days.</h4>
                    <h2 style="margin-top: 20px; text-align:center; color:blue; ba"><a href="/app/profile/{{auth()->user()->id}}/edit" >Complete Your Profile</a></h2>
                  </div>
                </div>
    </x-filament::section>
</x-filament-widgets::widget>
